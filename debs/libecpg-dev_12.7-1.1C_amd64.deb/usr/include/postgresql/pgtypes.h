/* src/interfaces/ecpg/include/pgtypes.h */

#ifndef PGTYPES_H
#define PGTYPES_H

#ifdef __cplusplus
extern "C"
{
#endif

extern void PGTYPESchar_free(char *ptr);

#ifdef __cplusplus
}
#endif

#endif							/* PGTYPES_H */
